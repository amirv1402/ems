export default function Home() {
  return (
    <main>
      <h1>Welcome to DR.EMS</h1>
      <p>This is the main landing page for emergency medical information.</p>
      <nav>
        <a href="/emergency">Emergency Info</a> | 
        <a href="/vip">VIP Section</a> | 
        <a href="/comments">Comments</a>
      </nav>
      <div style={{ marginTop: '20px' }}>
        <a href="/en">English</a>
      </div>
    </main>
  );
}
export default function EmergencyInfo() {
  return (
    <main>
      <h1>Emergency Information</h1>
      <p>Here you can publish emergency medical articles and case reports.</p>
    </main>
  );
}
export default function VIPSection() {
  return (
    <main>
      <h1>VIP Members Area</h1>
      <p>Only registered users can access VIP content.</p>
    </main>
  );
}
export default function Comments() {
  return (
    <main>
      <h1>Comments</h1>
      <p>Visitors can leave feedback and suggestions here.</p>
    </main>
  );
}<img src="/logo.png" alt="DR.EMS Logo" />
body {
  background-image: url('/bg-logo.png');
}

