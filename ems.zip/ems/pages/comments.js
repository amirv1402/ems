export default function Comments() {
  return (
    <main>
      <h1>Comments</h1>
      <p>Visitors can leave feedback and suggestions here.</p>
    </main>
  );
}
