export default function EmergencyInfo() {
  return (
    <main>
      <h1>Emergency Information</h1>
      <p>Here you can publish emergency medical articles and case reports.</p>
    </main>
  );
}
