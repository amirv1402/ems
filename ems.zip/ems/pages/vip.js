export default function VIPSection() {
  return (
    <main>
      <h1>VIP Members Area</h1>
      <p>Only registered users can access VIP content.</p>
    </main>
  );
}
