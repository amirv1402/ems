export default function Home() {
  return (
    <main>
      <h1>Welcome to DR.EMS</h1>
      <p>This is the main landing page for emergency medical information.</p>
      <nav>
        <a href="/emergency">Emergency Info</a> | 
        <a href="/vip">VIP Section</a> | 
        <a href="/comments">Comments</a>
      </nav>
      <div style={{ marginTop: '20px' }}>
        <a href="/en">English</a>
      </div>
    </main>
  );
}
